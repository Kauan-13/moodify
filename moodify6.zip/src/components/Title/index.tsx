import style from "./style.module.css"

const Title = () =>{

    return <>
    <div className={style.container}><p>Qual seu <em>mood</em> hoje? </p></div> 
    </>


}

export default Title